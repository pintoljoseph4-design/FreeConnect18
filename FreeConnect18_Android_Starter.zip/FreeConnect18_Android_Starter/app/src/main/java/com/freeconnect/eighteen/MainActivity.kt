package com.freeconnect.eighteen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101018)
private val Panel = Color(0xFF1D1D29)
private val Pink = Color(0xFFFF4F87)
private val Muted = Color(0xFFB9B9C8)

data class Member(val name: String, val age: Int, val about: String, val initials: String)

private val demoMembers = listOf(
    Member("Maya", 25, "Music, movies and good conversations", "M"),
    Member("Lina", 28, "Here to meet new people respectfully", "L"),
    Member("Talia", 24, "Beach walks and island culture", "T")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FreeConnectApp() }
    }
}

@Composable
fun FreeConnectApp() {
    var ageConfirmed by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("Discover") }
    var selected by remember { mutableStateOf<Member?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pink,
            background = Ink,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (!ageConfirmed) {
                AgeGate(onContinue = { ageConfirmed = true })
            } else if (selected != null) {
                ProfileScreen(
                    member = selected!!,
                    onBack = { selected = null },
                    onCall = { notice = "Call requests will work after a secure video-call service is connected." },
                    onReport = { notice = "Report flow placeholder: connect this to the moderation service before launch." }
                )
            } else {
                Scaffold(
                    containerColor = Ink,
                    snackbarHost = { SnackbarHost(hostState = remember { SnackbarHostState() }) },
                    bottomBar = {
                        NavigationBar(containerColor = Panel) {
                            NavigationBarItem(
                                selected = tab == "Discover",
                                onClick = { tab = "Discover" },
                                icon = { Icon(Icons.Default.Explore, null) },
                                label = { Text("Discover") }
                            )
                            NavigationBarItem(
                                selected = tab == "Calls",
                                onClick = { tab = "Calls" },
                                icon = { Icon(Icons.Default.Call, null) },
                                label = { Text("Calls") }
                            )
                            NavigationBarItem(
                                selected = tab == "Profile",
                                onClick = { tab = "Profile" },
                                icon = { Icon(Icons.Default.Person, null) },
                                label = { Text("My profile") }
                            )
                        }
                    }
                ) { padding ->
                    Column(Modifier.padding(padding).fillMaxSize()) {
                        Header()
                        when (tab) {
                            "Discover" -> DiscoverScreen(onMember = { selected = it })
                            "Calls" -> EmptyState(
                                Icons.Default.Call,
                                "Your calls",
                                "Accepted and missed calls will appear here once accounts and calling are connected."
                            )
                            else -> EmptyState(
                                Icons.Default.AccountCircle,
                                "Your profile",
                                "Profile editing and photo upload will be enabled after secure sign-in is added."
                            )
                        }
                    }
                }
                notice?.let { message ->
                    AlertDialog(
                        onDismissRequest = { notice = null },
                        title = { Text("Coming in the connected version") },
                        text = { Text(message) },
                        confirmButton = { TextButton(onClick = { notice = null }) { Text("OK") } },
                        containerColor = Panel
                    )
                }
            }
        }
    }
}

@Composable
fun AgeGate(onContinue: () -> Unit) {
    var checked by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("FreeConnect", color = Pink, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("18+", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("Meet adults. Connect respectfully.", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Text(
            "This service is for adults aged 18 and over. Everyone must be an adult and freely agree before any private video call.",
            color = Muted
        )
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { checked = it }, colors = CheckboxDefaults.colors(checkedColor = Pink))
            Text("I confirm that I am 18 or older", color = Color.White)
        }
        Button(
            onClick = onContinue,
            enabled = checked,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Pink)
        ) { Text("Continue") }
        Spacer(Modifier.height(14.dp))
        Text("Age confirmation here is a prototype only; production launch needs stronger age assurance.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun Header() {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Text("FreeConnect 18+", color = Pink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Discover adults who are open to connecting", color = Muted, fontSize = 13.sp)
    }
}

@Composable
fun DiscoverScreen(onMember: (Member) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = demoMembers.filter { it.name.contains(query, ignoreCase = true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search profiles") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Pink,
                unfocusedBorderColor = Panel,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        Spacer(Modifier.height(14.dp))
        Text("Suggested profiles", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(filtered) { member ->
                MemberCard(member = member, onClick = { onMember(member) })
            }
        }
        if (filtered.isEmpty()) {
            Text("No matching demo profiles.", color = Muted, modifier = Modifier.padding(16.dp))
        }
        Text(
            "Demo profiles only — no real people are connected in this starter build.",
            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp)
        )
    }
}

@Composable
fun MemberCard(member: Member, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp))
            .clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).background(Pink.copy(alpha = 0.18f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(member.initials, color = Pink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("${member.name}, ${member.age}", color = Color.White, fontWeight = FontWeight.Bold)
            Text(member.about, color = Muted, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = "View profile", tint = Muted)
    }
}

@Composable
fun ProfileScreen(member: Member, onBack: () -> Unit, onCall: () -> Unit, onReport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Back") }
        Spacer(Modifier.height(24.dp))
        Box(
            Modifier.size(112.dp).background(Pink.copy(alpha = 0.18f), CircleShape).align(Alignment.CenterHorizontally),
            contentAlignment = Alignment.Center
        ) { Text(member.initials, color = Pink, fontSize = 44.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(18.dp))
        Text("${member.name}, ${member.age}", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(member.about, color = Muted)
        Spacer(Modifier.height(26.dp))
        Button(onClick = onCall, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
            Icon(Icons.Default.Videocam, null); Spacer(Modifier.width(8.dp)); Text("Request video call")
        }
        OutlinedButton(onClick = onReport, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Flag, null); Spacer(Modifier.width(8.dp)); Text("Report profile")
        }
        Text("Calls must be accepted by both adults. Either person can end a call or block the other.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun EmptyState(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = Pink, modifier = Modifier.size(52.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(detail, color = Muted)
    }
}
