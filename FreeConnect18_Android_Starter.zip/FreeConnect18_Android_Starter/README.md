# FreeConnect 18+ — Android starter

This is a native Kotlin + Jetpack Compose starter project. It contains a dark UI, an 18+ confirmation screen, searchable demo profiles, profile detail screens, and placeholder call/report actions.

## Important status
This is **not a production app and does not make real video calls yet**. The profiles are fictional demo entries. Age confirmation is only a prototype checkbox, not reliable age verification. Do not publish this build or collect real users until authentication, age assurance, consent, moderation, privacy controls, and a secure video backend are implemented and tested.

## Open and build
1. Install Android Studio (current stable) on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `FreeConnect18_Android_Starter` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location after a successful build.

A computer with Android Studio and internet access is required to compile this project. This chat has generated the source project, not a compiled APK.

## Required work before real launch
- Secure sign-up/login and account deletion.
- Strong age assurance suitable for an adults-only service.
- User-submitted profile moderation and reporting workflows.
- Explicit call consent, block lists, abuse response and safety escalation.
- Secure video calling using a WebRTC-based provider/service, with server-issued short-lived room tokens. Never put provider secrets in the Android app.
- Backend database and storage rules that prevent users from reading private data.
- Privacy policy, terms, data-retention rules, and legal/app-store review.
- Network and device testing, including low-bandwidth conditions.

## Free-to-user model
Calls can be free to users, but video infrastructure, storage, moderation, and hosting may still cost the app operator. Choose a provider and operating budget before launch.
